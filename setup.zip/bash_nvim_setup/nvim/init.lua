-- Line numbers
vim.opt.number = true
-- vim.opt.relativenumber = true

-- Bootstrap lazy.nvim
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"

if not (vim.uv or vim.loop).fs_stat(lazypath) then
    vim.fn.system({
        "git",
        "clone",
        "--filter=blob:none",
        "--branch=stable",
        "https://github.com/folke/lazy.nvim.git",
        lazypath,
    })
end

vim.opt.rtp:prepend(lazypath)

-- Plugins
require("lazy").setup({
    {
        "ellisonleao/gruvbox.nvim",
        priority = 1000,

        config = function()
            require("gruvbox").setup({
                italic = {
                    comments = false,
		    strings = false,
    		operators = false,
    		folds = false,
                },
            })

            vim.o.background = "dark"
            vim.cmd("colorscheme gruvbox")

            -- Make comments non-italic
            vim.api.nvim_set_hl(0, "Comment", {
                italic = false,
            })
        end,
    },

    { import = "plugins" },
})
