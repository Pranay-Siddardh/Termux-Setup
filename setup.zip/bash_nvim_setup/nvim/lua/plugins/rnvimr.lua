return {
    "kevinhwang91/rnvimr",

    config = function()
        vim.g.rnvimr_enable_ex = 1
        vim.g.rnvimr_enable_picker = 1
        vim.g.rnvimr_hide_gitignore = 1

        vim.keymap.set("n", "<A-o>", ":RnvimrToggle<CR>", {
            silent = true,
        })
    end,
}
