return {
    {
        'akinsho/toggleterm.nvim',
        version = "*",
        config = function()
            require("toggleterm").setup({
                direction = 'float',
                close_on_exit = false,
                start_in_insert = true,
                float_opts = {
                    border = 'curved',
                    width = math.ceil(vim.o.columns * 0.8),
                    height = math.ceil(vim.o.lines * 0.8),
                },
            })

            -- Smart Runner Function
            local function run_current_file()
                vim.cmd("w")
                local filetype = vim.bo.filetype
                local file = vim.fn.expand('%')
                local inner_cmd = ""

                if filetype == "c" then
                    inner_cmd = "rcc " .. vim.fn.shellescape(file) .. "; echo ''; echo '--- Press q to close ---'; while [ \"$(read -n 1 -s; echo $REPLY)\" != \"q\" ]; do :; done"
                elseif filetype == "python" then
                    inner_cmd = "python3 -u " .. vim.fn.shellescape(file) .. "; echo ''; echo '--- Press q to close ---'; while [ \"$(read -n 1 -s; echo $REPLY)\" != \"q\" ]; do :; done"
                end

                if inner_cmd ~= "" then
                    -- Wrap in bash -ic so your shell profile and rcc command are loaded
                    local full_cmd = "bash -ic " .. vim.fn.shellescape(inner_cmd)
                    local Terminal = require('toggleterm.terminal').Terminal
                    local code_runner = Terminal:new({
                        cmd = full_cmd,
                        hidden = true,
                        direction = "float",
                        close_on_exit = true,
                        on_open = function(term)
                            vim.cmd("startinsert!")
                        end,
                    })
                    code_runner:toggle()
                end
            end

            vim.keymap.set('n', '<F5>', run_current_file, { desc = "Run Code" })

            -- 🛠️ THE 'q' TO EXIT FIX
            vim.api.nvim_create_autocmd("TermOpen", {
                pattern = "term://*",
                callback = function()
                    vim.keymap.set('n', 'q', '<cmd>close<CR>', { buffer = true, silent = true })
                    vim.keymap.set('t', '<Esc>', [[<C-\><C-n>]], { buffer = true, silent = true })
                end,
            })
        end
    }
}
